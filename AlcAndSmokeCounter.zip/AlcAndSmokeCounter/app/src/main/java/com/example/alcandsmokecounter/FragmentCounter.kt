package com.example.alcandsmokecounter

import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentContainerView
import androidx.navigation.fragment.findNavController
import java.text.SimpleDateFormat
import java.util.Date
import java.util.concurrent.TimeUnit

class FragmentCounter : Fragment() {
    private var dateStart = ""

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.counter_fragment, container, false)


        val cigPrice = arguments?.getString("cigPrice").toString()
        val cigPerDay = arguments?.getString("cigPerDay").toString()
        val alcPrice = arguments?.getString("alcPrice").toString()
        dateStart = arguments?.getString("dateStart")!!
        if (arguments?.getBoolean("firstTime") == false) {
            findNavController().graph.setStartDestination(R.layout.counter_fragment)
        }

        val daysNSmoke = view.findViewById<TextView>(R.id.smokingDays)
        val daysNDrink = view.findViewById<TextView>(R.id.drinkDays)
        val moneySaved = view.findViewById<TextView>(R.id.moneySaved)
        val cigsPerDay = view.findViewById<TextView>(R.id.cigsTotal)


        view.findViewById<Button>(R.id.stopButton).setOnClickListener {
            val sdf = SimpleDateFormat("dd/M/yyyy")
            val currentDate = sdf.format(Date())
            val days = TimeUnit.DAYS.convert(
                sdf.parse(currentDate).time -
                        sdf.parse(dateStart).time,
                TimeUnit.MILLISECONDS
            )

            daysNSmoke.text = days.toString()
            daysNDrink.text = days.toString()
            moneySaved.text = (cigPrice.toInt() + alcPrice.toInt()).toString()
            if (daysNSmoke.text.equals("0")) {
                cigsPerDay.text = cigPerDay
            } else {
                cigsPerDay.text =
                    (cigPerDay.toInt() * daysNSmoke.text.toString().toInt()).toString()
            }
        }





        return view
    }
}