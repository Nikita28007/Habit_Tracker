package com.example.alcandsmokecounter

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.Date

class detailsVarFragment : Fragment() {

    val args = navArgs<>()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.details_fragment, container, false)

        view.findViewById<Button>(R.id.detailNextButton).setOnClickListener {
            val cigPrice = view.findViewById<TextInputEditText>(R.id.cigPrice).text
            val cigPerDay = view.findViewById<TextInputEditText>(R.id.cigPerDay).text
            val alcPrice = view.findViewById<TextInputEditText>(R.id.alcPrice).text
            val sdf = SimpleDateFormat("dd/M/yyyy")
            val currentDate = sdf.format(Date())
            firstTime = false
            val bundle = Bundle()
            bundle.putString("cigPrice", cigPrice.toString())
            bundle.putString("cigPerDay", cigPerDay.toString())
            bundle.putString("alcPrice", alcPrice.toString())
            bundle.putString("dateStart", currentDate)
            bundle.putBoolean("firstTime", firstTime)



            findNavController().navigate(R.id.action_detailsVarFragment_to_fragmentCounter, bundle)

        }
        return view
    }


}